import SearchMessage from "./SearchMessage";

export default SearchMessage;
