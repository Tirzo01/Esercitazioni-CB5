import { useState } from "react";
import { useEffect } from "react";
import { GET } from "../../utils/http";

export function SearchMessage() {
  const [titleText, setTitleText] = useState("");
  const [posts, setPosts] = useState({});

  useEffect(() => {
    GET("posts").then(({ posts }) => {
      setPosts(posts);
    });
  }, []);

  console.log(posts);

  const onHandleInput = (e) => {
    setTitleText(e.target.value);
  };
  return (
    <div className="SearchMessage">
      <form>
        <input
          type="text"
          name=""
          id=""
          onChange={onHandleInput}
          placeholder="Cerca per titolo..."
        />
        <input type="submit" value="Cerca" />
      </form>
    </div>
  );
}
