import Friend from "./Friend";

export default Friend;
