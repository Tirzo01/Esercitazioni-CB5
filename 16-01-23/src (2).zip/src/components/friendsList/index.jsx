import FriendList from "./FriendList";

export default FriendList;
