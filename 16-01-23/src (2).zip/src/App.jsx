import "./App.css";
import { FriendList } from "./components/friendsList/FriendList";
import MessageList from "./components/messageList";
import { SearchMessage } from "./components/searchMessage/SearchMessage";

function App() {
  return (
    <div className="App">
      <FriendList />
      <MessageList />
    </div>
  );
}

export default App;
