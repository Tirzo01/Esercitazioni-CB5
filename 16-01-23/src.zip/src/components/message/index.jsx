import Message from "./Message";

export default Message;
