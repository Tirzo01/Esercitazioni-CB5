import PostsList from "./PostsList";

export default PostsList;
